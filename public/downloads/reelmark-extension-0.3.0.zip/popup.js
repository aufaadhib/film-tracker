const providerLabels = {
  netflix: "Netflix",
  disney: "Disney+",
  prime_video: "Prime Video",
  max: "Max",
};

const pairForm = document.getElementById("pair-form");
const pairCode = document.getElementById("pair-code");
const pairMessage = document.getElementById("pair-message");
const connectionState = document.getElementById("connection-state");
const footerState = document.getElementById("footer-state");
const loginButton = document.getElementById("login-button");
const disconnectButton = document.getElementById("disconnect-button");
const manualRecovery = document.getElementById("manual-recovery");
const deviceName = `Chrome / Edge · ${navigator.platform || "Browser"}`;

function renderSummary(summary) {
  const watched = summary?.watched ?? [];
  const inProgress = summary?.inProgress ?? [];
  const connected = Boolean(summary?.connected);
  document.getElementById("watched-count").textContent = String(watched.length).padStart(2, "0");
  document.getElementById("active-count").textContent = String(summary?.activeCount ?? 0).padStart(2, "0");
  connectionState.textContent = connected ? "Terhubung" : "Belum terhubung";
  connectionState.classList.toggle("connected", connected);
  loginButton.hidden = connected;
  disconnectButton.hidden = !connected;
  manualRecovery.hidden = connected;
  pairMessage.textContent = connected
    ? "Tontonan selesai akan disinkronkan otomatis."
    : "Masuk sekali untuk menyinkronkan tontonan ke akunmu.";
  footerState.textContent = connected
    ? "Terhubung ke akun Reelmark · antrean offline aktif."
    : "Data disimpan lokal sampai akun dihubungkan.";

  const progressList = document.getElementById("in-progress");
  progressList.replaceChildren(...(inProgress.length ? inProgress.slice(0, 4).map((item) => {
    const row = document.createElement("li");
    row.className = "progress-item";
    const heading = document.createElement("div");
    const title = document.createElement("strong");
    const percent = document.createElement("span");
    const provider = document.createElement("small");
    const progress = document.createElement("progress");
    title.textContent = item.title;
    percent.textContent = `${item.coverage}%`;
    provider.textContent = providerLabels[item.provider] ?? item.provider;
    progress.max = 100;
    progress.value = item.coverage;
    progress.setAttribute("aria-label", `Progres ${item.title}: ${item.coverage}%`);
    heading.append(title, percent);
    row.append(heading, progress, provider);
    return row;
  }) : [Object.assign(document.createElement("li"), {
    className: "empty",
    textContent: "Belum ada tontonan dalam progres.",
  })]));

  const recent = document.getElementById("recent");
  recent.replaceChildren(...(watched.length ? watched.slice(0, 4).map((item) => {
    const row = document.createElement("li");
    const title = document.createElement("strong");
    const provider = document.createElement("span");
    title.textContent = item.title;
    provider.textContent = providerLabels[item.provider] ?? item.provider;
    row.append(title, provider);
    return row;
  }) : [Object.assign(document.createElement("li"), {
    className: "empty",
    textContent: "Belum ada tontonan yang selesai.",
  })]));
}

function loadSummary() {
  chrome.runtime.sendMessage({ type: "GET_SUMMARY" }, (summary) => {
    if (chrome.runtime.lastError) {
      pairMessage.textContent = "Service worker extension belum siap. Buka kembali popup.";
      return;
    }
    renderSummary(summary);
  });
}

loginButton.addEventListener("click", () => {
  loginButton.disabled = true;
  pairMessage.textContent = "Membuka login Google…";
  chrome.runtime.sendMessage({ type: "LOGIN", payload: { deviceName } }, (result) => {
    loginButton.disabled = false;
    if (chrome.runtime.lastError || !result?.ok) {
      pairMessage.textContent = result?.error ?? "Login belum berhasil. Pastikan Reelmark lokal sedang berjalan.";
      return;
    }
    loadSummary();
  });
});

disconnectButton.addEventListener("click", () => {
  disconnectButton.disabled = true;
  pairMessage.textContent = "Memutuskan akun…";
  chrome.runtime.sendMessage({ type: "DISCONNECT" }, (result) => {
    disconnectButton.disabled = false;
    if (chrome.runtime.lastError || !result?.ok) {
      pairMessage.textContent = result?.error ?? "Akun belum berhasil diputuskan.";
      return;
    }
    loadSummary();
  });
});

pairCode.addEventListener("input", () => {
  const normalized = pairCode.value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, "").slice(0, 8);
  pairCode.value = normalized.length > 4 ? `${normalized.slice(0, 4)} ${normalized.slice(4)}` : normalized;
});

pairForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const button = pairForm.querySelector("button");
  button.disabled = true;
  pairMessage.textContent = "Menghubungkan…";

  chrome.runtime.sendMessage({
    type: "PAIR",
    payload: { code: pairCode.value, deviceName },
  }, (result) => {
    button.disabled = false;
    if (chrome.runtime.lastError || !result?.ok) {
      pairMessage.textContent = result?.error ?? "Pairing gagal. Pastikan dashboard lokal sedang berjalan.";
      return;
    }
    loadSummary();
  });
});

loadSummary();
